Supplementary Code and Data for Manuscript:
Integrated in silico network toxicology, machine learning and molecular simulations to predict candidate colorectal cancer-related targets of three novel non-phthalate plasticizers

Source code for bioinformatics analysis of the manuscript submitted to Discover Oncology.
This repository contains all R scripts for exploring the carcinogenic mechanisms of non‑phthalate plasticizers in colorectal cancer.

 ##Project structure

Code_Data/
├─ Batch-correction-and-differential-expression-analysis/
│  ├─ Batch-correction-and-differential-expression-analysis.R
│  └─ Processed_Data/
├─ machine-learning-and-SHAP-analysis/
│  ├─ ML_SHAP_analysis.R
│  └─ Processed_Data/
└─ WGCNA/
├─ WGCNA.R
└─ Processed_Data/

##Environment
- R version: 4.5.1
- Main R packages: limma, WGCNA, randomForest, xgboost, SHAP, ggplot2, pheatmap, survival, clusterProfiler

##Analysis Workflow
1. Batch correction and differential expression analysis
2. Weighted gene co-expression network analysis (WGCNA)
3. Machine learning model construction and SHAP interpretation

## Data availability
Raw transcriptome data are available at [GEO accession: GSEXXXXXX].
Processed intermediate data are stored in the `Processed_Data` subfolders within each module.

## Usage
Run R scripts sequentially according to the workflow order.
All scripts are annotated with parameters and thresholds used in this manuscript.

## License
MIT License