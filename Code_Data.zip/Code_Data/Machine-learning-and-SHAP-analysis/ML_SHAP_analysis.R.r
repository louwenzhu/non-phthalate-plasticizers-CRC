#==============================================================================#
#  塑化剂致结直肠癌核心靶点筛选 —— 机器学习与SHAP分析完整流程
#  替代型塑化剂 × 结直肠癌（CRC）79个交集靶点
#  训练集：GSE21510 + GSE9348（去批次后）
#  外部验证集：GSE24514、GSE32323
#  输出：117种模型AUC热图 + SHAP全套可视化（PDF/JPG，300dpi）
#==============================================================================#

#=========================== 0. 环境设置与包加载 ===============================#
rm(list = ls())
gc()

# 设置工作目录（请根据实际路径修改）
setwd("C:/Users/ASUS/Desktop/7月重头再来/5 ML and SHAP/第二次8.3")

# 所需R包列表
required_packages <- c(
  "glmnet", "e1071", "randomForestSRC", "gbm", "MASS",
  "xgboost", "klaR", "plsRglm", "caret", "pROC",
  "ggplot2", "pheatmap", "reshape2", "dplyr", "tidyr",
  "kernelshap", "shapviz", "gridExtra", "cowplot",
  "readxl", "ROCR", "mboost"
)

# 自动安装缺失包
for (pkg in required_packages) {
  if (!require(pkg, character.only = TRUE, quietly = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
    library(pkg, character.only = TRUE)
  }
}

# 固定随机种子，保证可重复性
set.seed(123)

# 创建输出目录
dir.create("results", showWarnings = FALSE, recursive = TRUE)
dir.create("results/figures", showWarnings = FALSE, recursive = TRUE)
dir.create("results/tables", showWarnings = FALSE, recursive = TRUE)

# 图形输出参数统一设置
dpi_val <- 300
fig_width <- 8
fig_height <- 6

#==============================================================================#
#=========================== 1. 数据读取与预处理 ===============================#
#==============================================================================#

cat("=== 步骤1：数据读取与预处理 ===\n")

#--------------------------- 1.1 读取训练集数据 --------------------------------#
# 79个交集基因表达谱（训练集，已去批次）
expr_train <- read.csv("expr_79genes_extracted.csv",
                       row.names = 1, check.names = FALSE, stringsAsFactors = FALSE)

# 训练集样本信息
meta_train <- read.csv("sample_metadata.csv",
                       stringsAsFactors = FALSE, check.names = FALSE)

# 统一group命名（control/Control统一为control）
meta_train$group <- tolower(meta_train$group)
meta_train$group[meta_train$group == "control"] <- "control"
meta_train$group <- factor(meta_train$group, levels = c("control", "crc"))

# 表达矩阵转置：行=样本，列=基因
expr_train_t <- as.data.frame(t(expr_train))
expr_train_t$sample_id <- rownames(expr_train_t)

# 合并表达数据与样本信息
train_data <- merge(meta_train, expr_train_t, by = "sample_id")
rownames(train_data) <- train_data$sample_id
train_data$sample_id <- NULL

cat("训练集样本数：", nrow(train_data), "  基因数：", ncol(train_data) - 1, "\n")
cat("训练集分组：", paste(table(train_data$group), collapse = " / "), "\n")

#--------------------------- 1.2 读取外部验证集 --------------------------------#
# 验证集1：GSE24514
expr_val1 <- read.csv("expr_79genes_GSE24514.csv",
                      row.names = 1, check.names = FALSE, stringsAsFactors = FALSE)
meta_val1 <- read_excel("GSE24514 Sample metadata.xlsx")
meta_val1 <- as.data.frame(meta_val1)

# 验证集2：GSE32323（文件名可能为GSE32323，按实际文件读取）
val2_file <- "expr_79genes_GSE32323.csv"
if (!file.exists(val2_file)) {
  val2_file <- "expr_79genes_GSE32323.csv"  # 兼容文件名差异
}
expr_val2 <- read.csv(val2_file,
                      row.names = 1, check.names = FALSE, stringsAsFactors = FALSE)

meta_val2_file <- "GSE32323 Sample metadata.xlsx"
if (!file.exists(meta_val2_file)) {
  meta_val2_file <- "GSE32323 Sample metadata.xlsx"
}
meta_val2 <- read_excel(meta_val2_file)
meta_val2 <- as.data.frame(meta_val2)

#--------------------------- 1.3 验证集预处理 ----------------------------------#
# 统一验证集样本信息列名（适配不同列名格式）
preprocess_meta <- function(meta_df) {
  # 尝试识别样本ID列和分组列
  colnames(meta_df) <- tolower(colnames(meta_df))
  
  # 样本ID列
  sample_col <- grep("sample|gsm|id", colnames(meta_df), value = TRUE)[1]
  # 分组列
  group_col <- grep("group|status|type|class|disease", colnames(meta_df), value = TRUE)[1]
  
  if (is.na(sample_col) || is.na(group_col)) {
    stop("无法识别样本信息文件中的样本ID列或分组列，请检查列名")
  }
  
  result <- data.frame(
    sample_id = meta_df[[sample_col]],
    group = tolower(meta_df[[group_col]]),
    stringsAsFactors = FALSE
  )
  
  # 统一分组命名
  result$group[grep("control|normal|healthy", result$group)] <- "control"
  result$group[grep("crc|cancer|tumor|tumour|carcinoma|colorectal", result$group)] <- "crc"
  result$group <- factor(result$group, levels = c("control", "crc"))
  
  return(result)
}

meta_val1 <- preprocess_meta(meta_val1)
meta_val2 <- preprocess_meta(meta_val2)

# 表达矩阵转置并合并
process_val_set <- function(expr_df, meta_df) {
  expr_t <- as.data.frame(t(expr_df))
  expr_t$sample_id <- rownames(expr_t)
  val_data <- merge(meta_df, expr_t, by = "sample_id")
  rownames(val_data) <- val_data$sample_id
  val_data$sample_id <- NULL
  return(val_data)
}

val1_data <- process_val_set(expr_val1, meta_val1)
val2_data <- process_val_set(expr_val2, meta_val2)

cat("验证集1（GSE24514）样本数：", nrow(val1_data), "\n")
cat("验证集2（GSE32323）样本数：", nrow(val2_data), "\n")

#--------------------------- 1.4 Z-score标准化 ---------------------------------#
# 训练集标准化（基于训练集自身均值和标准差）
gene_cols <- setdiff(colnames(train_data), "group")
train_means <- apply(train_data[, gene_cols], 2, mean)
train_sds <- apply(train_data[, gene_cols], 2, sd)

train_data[, gene_cols] <- scale(train_data[, gene_cols],
                                 center = train_means, scale = train_sds)

# 验证集独立标准化（各自队列内标准化，避免信息泄露）
val1_data[, gene_cols] <- scale(val1_data[, gene_cols])
val2_data[, gene_cols] <- scale(val2_data[, gene_cols])

# 添加高斯噪声增强稳健性（仅训练集）
noise_sd <- 0.01
for (gene in gene_cols) {
  train_data[, gene] <- train_data[, gene] + rnorm(nrow(train_data), 0, noise_sd)
}

cat("数据预处理完成\n\n")

#==============================================================================#
#===================== 2. 机器学习模型构建（113种模型） ========================#
#==============================================================================#

cat("=== 步骤2：构建113种机器学习模型 ===\n")

#--------------------------- 2.1 定义模型列表 ----------------------------------#
# 设计113种模型：单算法模型 + 两阶段组合模型（特征筛选 + 分类器）

# 单算法模型（17种）
single_models <- list(
  list(name = "Lasso", type = "single", method = "lasso"),
  list(name = "Ridge", type = "single", method = "ridge"),
  list(name = "Enet_alpha0.1", type = "single", method = "enet", alpha = 0.1),
  list(name = "Enet_alpha0.2", type = "single", method = "enet", alpha = 0.2),
  list(name = "Enet_alpha0.3", type = "single", method = "enet", alpha = 0.3),
  list(name = "Enet_alpha0.4", type = "single", method = "enet", alpha = 0.4),
  list(name = "Enet_alpha0.5", type = "single", method = "enet", alpha = 0.5),
  list(name = "Enet_alpha0.6", type = "single", method = "enet", alpha = 0.6),
  list(name = "Enet_alpha0.7", type = "single", method = "enet", alpha = 0.7),
  list(name = "Enet_alpha0.8", type = "single", method = "enet", alpha = 0.8),
  list(name = "Enet_alpha0.9", type = "single", method = "enet", alpha = 0.9),
  list(name = "SVM", type = "single", method = "svm"),
  list(name = "RF", type = "single", method = "rf"),
  list(name = "glmBoost", type = "single", method = "glmboost"),
  list(name = "Stepglm_forward", type = "single", method = "stepglm", direction = "forward"),
  list(name = "Stepglm_backward", type = "single", method = "stepglm", direction = "backward"),
  list(name = "Stepglm_both", type = "single", method = "stepglm", direction = "both"),
  list(name = "GBM", type = "single", method = "gbm"),
  list(name = "LDA", type = "single", method = "lda"),
  list(name = "XGBoost", type = "single", method = "xgboost"),
  list(name = "NaiveBayes", type = "single", method = "naivebayes"),
  list(name = "plsRglm", type = "single", method = "plsrglm")
)

# 特征筛选算法（6种核心方法）
fs_methods <- list(
  list(name = "Lasso", method = "lasso"),
  list(name = "Ridge", method = "ridge"),
  list(name = "Enet", method = "enet", alpha = 0.5),
  list(name = "RF", method = "rf"),
  list(name = "glmBoost", method = "glmboost"),
  list(name = "Stepglm", method = "stepglm", direction = "both")
)

# 分类器算法（12种）
classifier_methods <- list(
  list(name = "Lasso", method = "lasso"),
  list(name = "Ridge", method = "ridge"),
  list(name = "Enet", method = "enet", alpha = 0.5),
  list(name = "SVM", method = "svm"),
  list(name = "RF", method = "rf"),
  list(name = "glmBoost", method = "glmboost"),
  list(name = "Stepglm", method = "stepglm", direction = "both"),
  list(name = "GBM", method = "gbm"),
  list(name = "LDA", method = "lda"),
  list(name = "XGBoost", method = "xgboost"),
  list(name = "NaiveBayes", method = "naivebayes"),
  list(name = "plsRglm", method = "plsrglm")
)

# 生成两阶段组合模型（6 × 12 = 72种）
combo_models <- list()
for (fs in fs_methods) {
  for (clf in classifier_methods) {
    model_name <- paste0(fs$name, "+", clf$name)
    combo_models[[length(combo_models) + 1]] <- list(
      name = model_name,
      type = "combo",
      fs_method = fs$method,
      fs_params = fs[setdiff(names(fs), c("name", "method"))],
      clf_method = clf$method,
      clf_params = clf[setdiff(names(clf), c("name", "method"))]
    )
  }
}

# 额外Enet变体作为特征筛选（增加模型多样性）
extra_fs <- list(
  list(name = "Enet_a0.1", method = "enet", alpha = 0.1),
  list(name = "Enet_a0.9", method = "enet", alpha = 0.9)
)
for (fs in extra_fs) {
  for (clf in classifier_methods) {
    model_name <- paste0(fs$name, "+", clf$name)
    combo_models[[length(combo_models) + 1]] <- list(
      name = model_name,
      type = "combo",
      fs_method = fs$method,
      fs_params = fs[setdiff(names(fs), c("name", "method"))],
      clf_method = clf$method,
      clf_params = clf[setdiff(names(clf), c("name", "method"))]
    )
  }
}

# 合并所有模型（22 + 72 + 24 = 118，后续过滤少于5个基因的模型后约113种）
all_models <- c(single_models, combo_models)
cat("共定义", length(all_models), "种候选模型\n")

#--------------------------- 2.2 核心建模函数 ----------------------------------#

# 特征筛选函数
feature_select <- function(x, y, method, params = list(), min_features = 5) {
  y_num <- as.numeric(y) - 1  # control=0, crc=1
  
  if (method == "lasso") {
    cv_fit <- cv.glmnet(as.matrix(x), y_num, alpha = 1, family = "binomial",
                        nfolds = 10, type.measure = "auc")
    coefs <- as.matrix(coef(cv_fit, s = "lambda.min"))
    selected <- rownames(coefs)[which(coefs != 0)]
    selected <- setdiff(selected, "(Intercept)")
  } else if (method == "ridge") {
    cv_fit <- cv.glmnet(as.matrix(x), y_num, alpha = 0, family = "binomial",
                        nfolds = 10, type.measure = "auc")
    coefs <- as.matrix(coef(cv_fit, s = "lambda.min"))
    # 岭回归不做稀疏选择，按系数绝对值排序取top
    coef_vals <- abs(coefs[-1, 1])
    n_select <- max(min_features, round(length(coef_vals) * 0.3))
    selected <- names(sort(coef_vals, decreasing = TRUE))[1:n_select]
  } else if (method == "enet") {
    alpha_val <- ifelse(is.null(params$alpha), 0.5, params$alpha)
    cv_fit <- cv.glmnet(as.matrix(x), y_num, alpha = alpha_val, family = "binomial",
                        nfolds = 10, type.measure = "auc")
    coefs <- as.matrix(coef(cv_fit, s = "lambda.min"))
    selected <- rownames(coefs)[which(coefs != 0)]
    selected <- setdiff(selected, "(Intercept)")
  } else if (method == "rf") {
    rf_fit <- randomForestSRC::rfsrc(as.formula(paste("y ~", paste(colnames(x), collapse = " + "))),
                                     data = data.frame(y = y, x),
                                     ntree = 500, importance = TRUE)
    imp <- rf_fit$importance
    if (is.matrix(imp)) {
      imp_vals <- imp[, "all"]
    } else {
      imp_vals <- imp
    }
    n_select <- max(min_features, round(length(imp_vals) * 0.3))
    selected <- names(sort(imp_vals, decreasing = TRUE))[1:n_select]
  } else if (method == "glmboost") {
    y_num_fac <- factor(y_num)
    ctrl <- boost_control(mstop = 100, nu = 0.1)
    fit <- glmboost(as.matrix(x), y_num_fac, family = Binomial(), control = ctrl)
    coefs <- coef(fit)
    selected <- names(coefs)[abs(coefs) > 0]
    if (length(selected) < min_features) {
      coef_abs <- sort(abs(coefs), decreasing = TRUE)
      selected <- names(coef_abs)[1:min_features]
    }
  } else if (method == "stepglm") {
    direction <- ifelse(is.null(params$direction), "both", params$direction)
    df <- data.frame(y = y_num, x)
    full_formula <- as.formula(paste("y ~", paste(colnames(x), collapse = " + ")))
    null_formula <- as.formula("y ~ 1")
    full_fit <- glm(full_formula, data = df, family = binomial())
    step_fit <- step(full_fit, scope = list(lower = null_formula, upper = full_formula),
                     direction = direction, trace = 0)
    selected <- setdiff(names(coef(step_fit)), "(Intercept)")
  } else {
    selected <- colnames(x)
  }
  
  # 确保最少特征数
  if (length(selected) < min_features) {
    # 用t检验补充
    pvals <- apply(x, 2, function(gene) {
      t.test(gene[y == levels(y)[1]], gene[y == levels(y)[2]])$p.value
    })
    top_genes <- names(sort(pvals))[1:min_features]
    selected <- unique(c(selected, top_genes))[1:min_features]
  }
  
  return(selected)
}

# 分类器训练函数
train_classifier <- function(x, y, method, params = list()) {
  y_num <- as.numeric(y) - 1
  
  if (method == "lasso") {
    cv_fit <- cv.glmnet(as.matrix(x), y_num, alpha = 1, family = "binomial",
                        nfolds = 10, type.measure = "auc")
    model <- list(fit = cv_fit, method = "lasso", lambda = cv_fit$lambda.min)
  } else if (method == "ridge") {
    cv_fit <- cv.glmnet(as.matrix(x), y_num, alpha = 0, family = "binomial",
                        nfolds = 10, type.measure = "auc")
    model <- list(fit = cv_fit, method = "ridge", lambda = cv_fit$lambda.min)
  } else if (method == "enet") {
    alpha_val <- ifelse(is.null(params$alpha), 0.5, params$alpha)
    cv_fit <- cv.glmnet(as.matrix(x), y_num, alpha = alpha_val, family = "binomial",
                        nfolds = 10, type.measure = "auc")
    model <- list(fit = cv_fit, method = "enet", lambda = cv_fit$lambda.min, alpha = alpha_val)
  } else if (method == "svm") {
    df <- data.frame(y = y, x)
    svm_fit <- svm(y ~ ., data = df, kernel = "radial", probability = TRUE,
                   scale = FALSE, cost = 1, gamma = 1/ncol(x))
    model <- list(fit = svm_fit, method = "svm", features = colnames(x))
  } else if (method == "rf") {
    df <- data.frame(y = y, x)
    rf_fit <- randomForestSRC::rfsrc(y ~ ., data = df, ntree = 1000,
                                     nodesize = 5, importance = TRUE)
    model <- list(fit = rf_fit, method = "rf", features = colnames(x))
  } else if (method == "glmboost") {
    y_num_fac <- factor(y_num)
    ctrl <- boost_control(mstop = 100, nu = 0.1)
    fit <- glmboost(as.matrix(x), y_num_fac, family = Binomial(), control = ctrl)
    model <- list(fit = fit, method = "glmboost", features = colnames(x))
  } else if (method == "stepglm") {
    direction <- ifelse(is.null(params$direction), "both", params$direction)
    df <- data.frame(y = y_num, x)
    full_formula <- as.formula(paste("y ~", paste(colnames(x), collapse = " + ")))
    null_formula <- as.formula("y ~ 1")
    full_fit <- glm(full_formula, data = df, family = binomial())
    step_fit <- step(full_fit, scope = list(lower = null_formula, upper = full_formula),
                     direction = direction, trace = 0)
    model <- list(fit = step_fit, method = "stepglm", features = colnames(x))
  } else if (method == "gbm") {
    df <- data.frame(y = y_num, x)
    gbm_fit <- gbm(y ~ ., data = df, distribution = "bernoulli",
                   n.trees = 5000, interaction.depth = 3,
                   shrinkage = 0.001, cv.folds = 5, verbose = FALSE)
    best_iter <- gbm.perf(gbm_fit, method = "cv", plot.it = FALSE)
    model <- list(fit = gbm_fit, method = "gbm", n.trees = best_iter, features = colnames(x))
  } else if (method == "lda") {
    df <- data.frame(y = y, x)
    lda_fit <- lda(y ~ ., data = df)
    model <- list(fit = lda_fit, method = "lda", features = colnames(x))
  } else if (method == "xgboost") {
    dtrain <- xgb.DMatrix(data = as.matrix(x), label = y_num)
    params <- list(
      objective = "binary:logistic",
      eval_metric = "auc",
      max_depth = 3,
      eta = 0.01,
      subsample = 0.8,
      colsample_bytree = 0.8
    )
    cv_fit <- xgb.cv(params = params, data = dtrain, nrounds = 500,
                     nfold = 5, verbose = 0, early_stopping_rounds = 50)
    best_nrounds <- cv_fit$best_iteration
    xgb_fit <- xgboost(data = dtrain, params = params, nrounds = best_nrounds, verbose = 0)
    model <- list(fit = xgb_fit, method = "xgboost", nrounds = best_nrounds, features = colnames(x))
  } else if (method == "naivebayes") {
    df <- data.frame(y = y, x)
    nb_fit <- NaiveBayes(y ~ ., data = df)
    model <- list(fit = nb_fit, method = "naivebayes", features = colnames(x))
  } else if (method == "plsrglm") {
    df <- data.frame(y = y_num, x)
    # 使用plsRglm
    n_comp <- min(10, ncol(x) - 1)
    pls_fit <- plsRglm::plsRglm(y ~ ., data = df, nt = n_comp, family = "binomial", verbose = FALSE)
    model <- list(fit = pls_fit, method = "plsrglm", features = colnames(x), nt = pls_fit$nt)
  } else {
    stop(paste("未知分类器方法：", method))
  }
  
  return(model)
}

# 预测函数
predict_model <- function(model, newdata) {
  method <- model$method
  
  if (method %in% c("lasso", "ridge", "enet")) {
    preds <- as.numeric(predict(model$fit, newx = as.matrix(newdata), s = model$lambda, type = "response"))
  } else if (method == "svm") {
    preds <- attr(predict(model$fit, newdata, probability = TRUE), "probabilities")[, 2]
  } else if (method == "rf") {
    preds <- predict(model$fit, newdata)$predicted[, 2]
  } else if (method == "glmboost") {
    preds <- as.numeric(predict(model$fit, newdata = as.matrix(newdata), type = "response"))
  } else if (method == "stepglm") {
    preds <- as.numeric(predict(model$fit, newdata = newdata, type = "response"))
  } else if (method == "gbm") {
    preds <- as.numeric(predict(model$fit, newdata = newdata, n.trees = model$n.trees, type = "response"))
  } else if (method == "lda") {
    preds <- as.numeric(predict(model$fit, newdata = newdata)$posterior[, 2])
  } else if (method == "xgboost") {
    preds <- as.numeric(predict(model$fit, newdata = as.matrix(newdata)))
  } else if (method == "naivebayes") {
    preds <- as.numeric(predict(model$fit, newdata = newdata)$posterior[, 2])
  } else if (method == "plsrglm") {
    preds <- as.numeric(predict(model$fit, newdata = newdata, type = "response"))
  } else {
    stop(paste("未知预测方法：", method))
  }
  
  return(preds)
}

# 计算AUC
calc_auc <- function(true_labels, pred_probs) {
  roc_obj <- roc(true_labels, pred_probs, quiet = TRUE)
  return(as.numeric(auc(roc_obj)))
}

#--------------------------- 2.3 10折交叉验证 -----------------------------------#
cat("执行10折交叉验证...\n")

# 分层10折划分
n_samples <- nrow(train_data)
y_labels <- train_data$group
folds <- createFolds(y_labels, k = 10, list = TRUE, returnTrain = TRUE)

# 存储结果
cv_results <- data.frame(
  model_name = character(),
  cv_mean_auc = numeric(),
  cv_sd_auc = numeric(),
  n_features = integer(),
  stringsAsFactors = FALSE
)

# 存储每个模型的最终训练模型（用于外部验证）
final_models <- list()
model_features <- list()

# 遍历所有模型
for (i in seq_along(all_models)) {
  model_config <- all_models[[i]]
  model_name <- model_config$name
  
  cat(sprintf("  模型 %d/%d: %s\n", i, length(all_models), model_name))
  
  # 交叉验证AUC
  fold_aucs <- numeric(10)
  selected_features_cv <- list()
  
  for (k in 1:10) {
    train_idx <- folds[[k]]
    test_idx <- setdiff(1:n_samples, train_idx)
    
    fold_train <- train_data[train_idx, ]
    fold_test <- train_data[test_idx, ]
    
    fold_x_train <- fold_train[, gene_cols]
    fold_y_train <- fold_train$group
    fold_x_test <- fold_test[, gene_cols]
    fold_y_test <- fold_test$group
    
    tryCatch({
      if (model_config$type == "single") {
        # 单算法模型
        clf_params <- model_config[setdiff(names(model_config), c("name", "type", "method"))]
        model <- train_classifier(fold_x_train, fold_y_train, model_config$method, clf_params)
        preds <- predict_model(model, fold_x_test)
        selected_features_cv[[k]] <- gene_cols
      } else {
        # 两阶段组合模型
        # 第一阶段：特征筛选
        fs_params <- model_config$fs_params
        selected <- feature_select(fold_x_train, fold_y_train, model_config$fs_method, fs_params)
        selected_features_cv[[k]] <- selected
        
        if (length(selected) < 2) next
        
        # 第二阶段：分类器
        fold_x_train_sel <- fold_x_train[, selected, drop = FALSE]
        fold_x_test_sel <- fold_x_test[, selected, drop = FALSE]
        
        clf_params <- model_config$clf_params
        model <- train_classifier(fold_x_train_sel, fold_y_train, model_config$clf_method, clf_params)
        preds <- predict_model(model, fold_x_test_sel)
      }
      
      fold_aucs[k] <- calc_auc(fold_y_test, preds)
    }, error = function(e) {
      fold_aucs[k] <- NA
    })
  }
  
  # 计算平均AUC
  valid_aucs <- fold_aucs[!is.na(fold_aucs)]
  mean_auc <- ifelse(length(valid_aucs) > 0, mean(valid_aucs), NA)
  sd_auc <- ifelse(length(valid_aucs) > 1, sd(valid_aucs), NA)
  
  # 获取最终特征集（所有折的并集中出现频率最高的）
  all_selected <- unlist(selected_features_cv)
  freq_table <- table(all_selected)
  top_features <- names(sort(freq_table, decreasing = TRUE))
  n_feat <- min(length(top_features), 20)  # 取频率最高的20个左右
  
  cv_results <- rbind(cv_results, data.frame(
    model_name = model_name,
    cv_mean_auc = round(mean_auc, 4),
    cv_sd_auc = round(sd_auc, 4),
    n_features = n_feat,
    stringsAsFactors = FALSE
  ))
  
  # 用全部训练集训练最终模型
  tryCatch({
    if (model_config$type == "single") {
      clf_params <- model_config[setdiff(names(model_config), c("name", "type", "method"))]
      final_model <- train_classifier(train_data[, gene_cols], train_data$group,
                                      model_config$method, clf_params)
      final_features <- gene_cols
    } else {
      # 全训练集特征筛选
      fs_params <- model_config$fs_params
      selected_final <- feature_select(train_data[, gene_cols], train_data$group,
                                       model_config$fs_method, fs_params)
      final_features <- selected_final
      
      clf_params <- model_config$clf_params
      final_model <- train_classifier(train_data[, selected_final], train_data$group,
                                      model_config$clf_method, clf_params)
    }
    
    final_models[[model_name]] <- final_model
    model_features[[model_name]] <- final_features
  }, error = function(e) {
    final_models[[model_name]] <- NULL
    model_features[[model_name]] <- NULL
  })
}

# 过滤掉失败的模型和基因数太少的模型
cv_results <- cv_results[!is.na(cv_results$cv_mean_auc), ]
cv_results <- cv_results[order(-cv_results$cv_mean_auc), ]

# 筛选纳入基因≥5的模型（符合论文标准）
cv_results_valid <- cv_results[cv_results$n_features >= 5, ]
cat("有效模型数（≥5个基因）：", nrow(cv_results_valid), "\n")

# 保存交叉验证结果
write.csv(cv_results_valid, "results/tables/cv_auc_results.csv", row.names = FALSE)

cat("交叉验证完成\n\n")


# 存储所有模型筛选的基因
all_selected_genes <- data.frame(
  model_name = character(),
  selected_genes = character(),
  gene_count = integer(),
  stringsAsFactors = FALSE
)

# 遍历所有模型
for (i in seq_along(all_models)) {
  # ... 原有循环代码不变 ...
  
  # 用全部训练集训练最终模型
  tryCatch({
    if (model_config$type == "single") {
      clf_params <- model_config[setdiff(names(model_config), c("name", "type", "method"))]
      final_model <- train_classifier(train_data[, gene_cols], train_data$group,
                                      model_config$method, clf_params)
      final_features <- gene_cols
    } else {
      # 全训练集特征筛选
      fs_params <- model_config$fs_params
      selected_final <- feature_select(train_data[, gene_cols], train_data$group,
                                       model_config$fs_method, fs_params)
      final_features <- selected_final
      
      clf_params <- model_config$clf_params
      final_model <- train_classifier(train_data[, selected_final], train_data$group,
                                      model_config$clf_method)
    }
    
    final_models[[model_name]] <- final_model
    model_features[[model_name]]
    
    # ==========新增：记录该模型筛选基因==========
    all_selected_genes <- rbind(all_selected, data.frame(
      model_name = model_name,
      selected_genes = paste(final_features, collapse = ","),
      gene_count = length(final_features),
      stringsAsFactors = FALSE
    ))
    
  }, error = function(e) {
    final_models[[model_name]] <- NULL
    model_features[[model_name]] <- NULL
  })
}

# 循环结束后导出全部模型基因表
write.csv(all_selected_genes, "results/tables/all_model_selected_genes.csv", row.names = FALSE)
cat("全部118种模型筛选基因汇总表已保存至 results/tables/all_model_selected_genes\n")

#==============================================================================#
#=========================== 3. 外部验证与模型评估 =============================#
#==============================================================================#

cat("=== 步骤3：外部验证集评估 ===\n")

# 外部验证
val_results <- data.frame(
  model_name = character(),
  train_auc = numeric(),
  val1_auc = numeric(),
  val2_auc = numeric(),
  mean_auc = numeric(),
  stringsAsFactors = FALSE
)

for (model_name in cv_results_valid$model_name) {
  if (is.null(final_models[[model_name]])) next
  
  features <- model_features[[model_name]]
  model <- final_models[[model_name]]
  
  tryCatch({
    # 训练集AUC
    train_preds <- predict_model(model, train_data[, features, drop = FALSE])
    train_auc <- calc_auc(train_data$group, train_preds)
    
    # 验证集1 AUC
    # 确保验证集有这些基因
    common_genes_val1 <- intersect(features, colnames(val1_data))
    if (length(common_genes_val1) == length(features)) {
      val1_preds <- predict_model(model, val1_data[, features, drop = FALSE])
      val1_auc <- calc_auc(val1_data$group, val1_preds)
    } else {
      val1_auc <- NA
    }
    
    # 验证集2 AUC
    common_genes_val2 <- intersect(features, colnames(val2_data))
    if (length(common_genes_val2) == length(features)) {
      val2_preds <- predict_model(model, val2_data[, features, drop = FALSE])
      val2_auc <- calc_auc(val2_data$group, val2_preds)
    } else {
      val2_auc <- NA
    }
    
    mean_auc <- mean(c(train_auc, val1_auc, val2_auc), na.rm = TRUE)
    
    val_results <- rbind(val_results, data.frame(
      model_name = model_name,
      train_auc = round(train_auc, 4),
      val1_auc = round(val1_auc, 4),
      val2_auc = round(val2_auc, 4),
      mean_auc = round(mean_auc, 4),
      stringsAsFactors = FALSE
    ))
  }, error = function(e) {
    cat(sprintf("  模型 %s 外部验证失败: %s\n", model_name, e$message))
  })
}

val_results <- val_results[order(-val_results$mean_auc), ]
write.csv(val_results, "results/tables/external_validation_auc.csv", row.names = FALSE)

# 选取最优模型
best_model_name <- val_results$model_name[which.max(val_results$mean_auc)]
cat("最优模型：", best_model_name, "\n")
cat("  训练集AUC：", val_results$train_auc[which.max(val_results$mean_auc)], "\n")
cat("  验证集1 AUC：", val_results$val1_auc[which.max(val_results$mean_auc)], "\n")
cat("  验证集2 AUC：", val_results$val2_auc[which.max(val_results$mean_auc)], "\n")
cat("  平均AUC：", val_results$mean_auc[which.max(val_results$mean_auc)], "\n")

cat("外部验证完成\n\n")

#==============================================================================#
#=========================== 4. AUC热图（核心输出图） ==========================#
#==============================================================================#

cat("=== 步骤4：绘制AUC热图 ===\n")

# 加载依赖包
library(grid)
library(dplyr)
library(tidyr)
library(ComplexHeatmap)
library(circlize)

# 1 工作目录
setwd("C:/Users/ASUS/Desktop/7月重头再来/5 ML and SHAP/第二次8.3/results/tables")
if (!dir.exists("../figures")) {
  dir.create("../figures", recursive = TRUE)
}

# 2 读取数据
auc_df <- read.csv("external_validation_auc.csv", header = T)
model_names <- auc_df$model_name
mat <- auc_df[, c(2, 3, 4)] %>% as.matrix
rownames(mat) <- model_names
mean_auc_vec <- auc_df$mean_auc
n_row <- nrow(mat)

# 3 AUC渐变色
auc_col_fun <- colorRamp2(
  breaks = c(0.6, 0.7, 0.8, 0.9, 1.0),
  colors = c("#002060", "#2050c0", "#60a0ff", "#ff6020", "#c01010")
)

# 顶部注释
top_anno <- HeatmapAnnotation(
  df = data.frame(Dataset = c("train", "GSE24514", "GSE32323")),
  col = list(Dataset = c(
    "train" = "#87CEFA",
    "GSE24514" = "#2c5292",
    "GSE32323" = "#90EE90"
  )),
  show_legend = TRUE,
  annotation_name_side = "right",
  annotation_name_gp = gpar(fontsize = 10),
  annotation_legend_param = list(title = "Dataset"),
  height = unit(4, "mm")
)

# 单元格绘制：格子黑色细边框 + 内部3位AUC数值
cell_text_fun <- function(j, i, x, y, width, height, fill) {
  val <- mat[i, j]
  grid.text(sprintf("%.3f", val), x, y, gp = gpar(fontsize = 6, col = "black"))
  grid.rect(x, y, width, height, gp = gpar(col = "black", lwd = 0.8, fill = NA))
}

# 主热图
ht_main <- Heatmap(
  mat,
  name = "AUC",
  col = auc_col_fun,
  top_annotation = top_anno,
  show_row_dend = FALSE,
  show_column_dend = FALSE,
  show_row_names = TRUE,
  row_names_side = "left",
  row_names_gp = gpar(fontsize = 7),
  row_title = "Machine Learning Pipelines",
  row_title_gp = gpar(fontsize = 12, fontface = "bold"),
  show_column_names = FALSE,
  border = FALSE,
  cell_fun = cell_text_fun,
  width = unit(3.2, "inch"),
  height = unit(12, "inch")
)

# =========【关键修改：数值移至条形内部靠右】========
right_anno <- rowAnnotation(
  MeanAUC = anno_barplot(
    mean_auc_vec,
    bar_width = 0.7,
    gp = gpar(fill = "#99ccf0", col = NA),
    xlim = c(0.6, 1),
    border = FALSE,
    width = unit(2.0, "inch")
  ),
  label = anno_text(
    sprintf("%.4f", mean_auc_vec),
    location = unit(0.97, "native"),  # 0.97：条形内部靠右，向左移动
    just = "right",  # 对齐方式改为右对齐
    gp = gpar(fontsize = 6.2)
  ),
  show_legend = FALSE
)

# 合并画布
ht_list <- ht_main + right_anno

# 导出PDF：增加右侧画布留白，图例整体右移远离条形
pdf("../figures/Fig_AUC_heatmap.pdf", width = 16, height = 13) # 加宽画布
draw(
  ht_list,
  heatmap_legend_side = "right",
  annotation_legend_side = "right",
  legend_gap = unit(25, "mm"),   # 增大图例与绘图区域距离
  padding = unit(c(10, 40, 10, 10), "mm") # 顶部,右侧,底部,左侧留白，右侧加大
)
dev.off()

# 导出高清JPG
jpeg("../figures/Fig_AUC_heatmap.jpg", width = 4800, height = 3900, res = 300)
draw(
  ht_list,
  heatmap_legend_side = "right",
  annotation_legend_side = "right",
  legend_gap = unit(25, "mm"),
  padding = unit(c(10, 40, 10, 10), "mm")
)
dev.off()

cat("✅修改完成：\n1.MeanAUC数值移入浅蓝色条形内部靠右，不再向外延伸\n2.画布右侧留白增加，图例整体右移，彻底解决重叠\n")


#==============================================================================#
#=========================== 5. SHAP可解释性分析 ===============================#
#==============================================================================#

cat("=== 步骤5：SHAP可解释性分析 ===\n")

# 获取最优模型及其特征
best_model <- final_models[[best_model_name]]
best_features <- model_features[[best_model_name]]
cat("最优模型纳入基因数：", length(best_features), "\n")
cat("基因列表：", paste(best_features, collapse = ", "), "\n")

# 准备SHAP分析数据
x_train_best <- train_data[, best_features, drop = FALSE]
y_train_best <- train_data$group

# 定义预测函数（适配kernelshap）
pred_fun <- function(model, newdata) {
  predict_model(model, newdata)
}

# 计算SHAP值
cat("计算SHAP值中...\n")
shap_obj <- kernelshap(
  object = best_model,
  X = x_train_best,
  pred_fun = function(object, X) predict_model(object, X),
  bg_X = x_train_best[sample(1:nrow(x_train_best), min(50, nrow(x_train_best))), ],
  verbose = TRUE
)

# 创建shapviz对象
sv <- shapviz(shap_obj, X = x_train_best, y = as.numeric(y_train_best) - 1)

#--------------------------- 5.1 SHAP汇总图（蜂群图） --------------------------#
p_shap_summary <- sv_importance(sv, kind = "beeswarm", show_numbers = TRUE) +
  labs(title = "SHAP Summary Plot",
       subtitle = paste("Model:", best_model_name),
       x = "SHAP value (impact on model output)",
       y = "Features") +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
    plot.subtitle = element_text(hjust = 0.5, size = 10),
    axis.text = element_text(size = 10),
    axis.title = element_text(size = 11)
  )

ggsave("results/figures/Fig_SHAP_summary.pdf", p_shap_summary, width = fig_width, height = fig_height)
ggsave("results/figures/Fig_SHAP_summary.jpg", p_shap_summary, width = fig_width, height = fig_height, dpi = dpi_val)

#--------------------------- 5.2 SHAP重要性条形图 ------------------------------#
p_shap_bar <- sv_importance(sv, kind = "bar", show_numbers = TRUE) +
  labs(title = "Feature Importance (Mean |SHAP|)",
       subtitle = paste("Model:", best_model_name),
       x = "Mean absolute SHAP value",
       y = "Features") +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
    plot.subtitle = element_text(hjust = 0.5, size = 10),
    axis.text = element_text(size = 10),
    axis.title = element_text(size = 11)
  )

ggsave("results/figures/Fig_SHAP_importance_bar.pdf", p_shap_bar, width = fig_width, height = fig_height)
ggsave("results/figures/Fig_SHAP_importance_bar.jpg", p_shap_bar, width = fig_width, height = fig_height, dpi = dpi_val)

#--------------------------- 5.3 SHAP依赖图（Top5基因） ------------------------#
top5_genes <- names(sort(apply(shap_obj$S, 2, function(x) mean(abs(x))), decreasing = TRUE))[1:5]

dep_plots <- list()
for (gene in top5_genes) {
  p <- sv_dependence(sv, v = gene, color_var = gene) +
    labs(title = paste("SHAP Dependence Plot:", gene),
         x = paste(gene, "expression (z-score)"),
         y = "SHAP value") +
    theme_minimal() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 12, face = "bold"),
      axis.text = element_text(size = 9),
      axis.title = element_text(size = 10),
      legend.position = "none"
    )
  dep_plots[[gene]] <- p
}

# 合并为2x3布局
p_dep_combined <- cowplot::plot_grid(plotlist = dep_plots, ncol = 2, nrow = 3)

ggsave("results/figures/Fig_SHAP_dependence_top5.pdf", p_dep_combined, width = 12, height = 15)
ggsave("results/figures/Fig_SHAP_dependence_top5.jpg", p_dep_combined, width = 12, height = 15, dpi = dpi_val)

#--------------------------- 5.4 SHAP力图（代表性样本） ------------------------#
# 选取一个典型CRC样本和一个典型对照样本
crc_indices <- which(y_train_best == "crc")
control_indices <- which(y_train_best == "control")

sample_crc <- crc_indices[1]  # 第一个CRC样本
sample_ctrl <- control_indices[1]  # 第一个对照样本

p_force_crc <- sv_force(sv, row_id = sample_crc) +
  labs(title = paste("SHAP Force Plot - CRC Sample", sample_crc),
       subtitle = paste("Predicted probability:", round(attr(sv, "baseline") + sum(shap_obj$S[sample_crc, ]), 3))) +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, size = 12, face = "bold"))

p_force_ctrl <- sv_force(sv, row_id = sample_ctrl) +
  labs(title = paste("SHAP Force Plot - Control Sample", sample_ctrl),
       subtitle = paste("Predicted probability:", round(attr(sv, "baseline") + sum(shap_obj$S[sample_ctrl, ]), 3))) +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, size = 12, face = "bold"))

p_force_combined <- cowplot::plot_grid(p_force_crc, p_force_ctrl, ncol = 1)

ggsave("results/figures/Fig_SHAP_force_plot.pdf", p_force_combined, width = 10, height = 8)
ggsave("results/figures/Fig_SHAP_force_plot.jpg", p_force_combined, width = 10, height = 8, dpi = dpi_val)

#--------------------------- 5.5 SHAP瀑布图 ------------------------------------#
p_waterfall_crc <- sv_waterfall(sv, row_id = sample_crc) +
  labs(title = paste("SHAP Waterfall Plot - CRC Sample", sample_crc)) +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, size = 12, face = "bold"))

p_waterfall_ctrl <- sv_waterfall(sv, row_id = sample_ctrl) +
  labs(title = paste("SHAP Waterfall Plot - Control Sample", sample_ctrl)) +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, size = 12, face = "bold"))

p_waterfall_combined <- cowplot::plot_grid(p_waterfall_crc, p_waterfall_ctrl, ncol = 1)

ggsave("results/figures/Fig_SHAP_waterfall.pdf", p_waterfall_combined, width = 10, height = 8)
ggsave("results/figures/Fig_SHAP_waterfall.jpg", p_waterfall_combined, width = 10, height = 8, dpi = dpi_val)

#--------------------------- 5.6 核心基因ROC曲线 -------------------------------#
# Top5基因单独的ROC曲线
roc_plots <- list()
for (gene in top5_genes) {
  roc_obj <- roc(y_train_best, x_train_best[[gene]], quiet = TRUE)
  auc_val <- round(as.numeric(auc(roc_obj)), 3)
  
  roc_df <- data.frame(
    fpr = 1 - roc_obj$specificities,
    tpr = roc_obj$sensitivities
  )
  
  p <- ggplot(roc_df, aes(x = fpr, y = tpr)) +
    geom_line(color = "#E41A1C", linewidth = 1) +
    geom_abline(intercept = 0, slope = 1, linetype = "dashed", color = "gray50") +
    labs(title = paste(gene, "(AUC =", auc_val, ")"),
         x = "False Positive Rate (1 - Specificity)",
         y = "True Positive Rate (Sensitivity)") +
    theme_minimal() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 11, face = "bold"),
      axis.text = element_text(size = 9),
      axis.title = element_text(size = 10)
    )
  roc_plots[[gene]] <- p
}

p_roc_combined <- cowplot::plot_grid(plotlist = roc_plots, ncol = 3, nrow = 2)

ggsave("results/figures/Fig_ROC_core_genes.pdf", p_roc_combined, width = 14, height = 10)
ggsave("results/figures/Fig_ROC_core_genes.jpg", p_roc_combined, width = 14, height = 10, dpi = dpi_val)




library(ggplot2)
library(pROC)
library(dplyr)

# 切换工作目录
setwd("C:/Users/ASUS/Desktop/7月重头再来/5 ML and SHAP/第二次8.3")

# 1 读取样本与表达数据
expr_train <- read.csv("expr_79genes_extracted.csv", row.names = 1, check.names = FALSE)
meta_train <- read.csv("sample_metadata.csv", stringsAsFactors = FALSE)

# ==========修复分组赋值BUG==========
meta_train$group <- tolower(meta_train$group)
# 匹配正常/肿瘤标签
meta_train$group[grep("control|normal|healthy", meta_train$group)] <- "control"
meta_train$group[grep("crc|cancer|tumor|tumour|carcinoma|colorectal", meta_train$group)] <- "crc"
meta_train$group <- factor(meta_train$group, levels = c("control", "crc"))
# 校验分组
cat("训练集分组统计：\n")
print(table(meta_train$group))


# 表达矩阵转置合并
expr_t <- as.data.frame(t(expr_train))
expr_t$sample_id <- rownames(expr_t)
train_data <- merge(meta_train, expr_t, by = "sample_id")
train_data$sample_id <- NULL

# 提取基因列
gene_cols <- setdiff(colnames(train_data), c("group_raw", "group_clean", "group"))

# 标准化
expr_mat <- train_data[, gene_cols]
train_means <- apply(expr_mat, 2, mean)
train_sds <- apply(expr_mat, 2, sd)
train_data[, gene_cols] <- scale(expr_mat, center = train_means, scale = train_sds)

# 读取SHAP基因
shap_import <- read.csv("results/tables/SHAP_importance_ranking.csv")
top5_genes <- shap_import$Gene[1:5]

# 绘制ROC
roc_all_data <- data.frame()
auc_label_text <- c()
line_cols <- c("#d62728", "#1f77b4", "#2ca02c", "#ff7f0e", "#9467bd")
names(line_cols) <- top5_genes

for (gene in top5_genes) {
  roc_obj <- roc(response = train_data$group, predictor = train_data[[gene]], quiet = TRUE)
  auc_val <- round(as.numeric(auc(roc_obj)), 3)
  
  temp_df <- data.frame(
    fpr = 1 - roc_obj$specificities,
    tpr = roc_obj$sensitivities,
    gene = gene
  )
  roc_all <- rbind(roc_all_data, temp_df)
  roc_all_data <- roc_all
  auc_label_text <- c(auc_label_text, paste0(gene, " AUC = ", auc_val))
}

label_all <- paste(auc_label_text, collapse = "\n")

p_roc_single <- ggplot(roc_all_data, aes(x = fpr, y = tpr, color = gene)) +
  geom_line(linewidth = 1.1) +
  geom_abline(intercept = 0, slope = 1, linetype = "dashed", color = "gray40", linewidth = 0.8) +
  scale_color_manual(values = line_cols) +
  annotate(
    "text",
    x = 0.72, y = 0.28,
    label = label_all,
    hjust = 0, size = 3.4,
    bbox = list(fill = "white", alpha = 0.8, linetype = "solid", color = "gray60")
  ) +
  labs(
    title = "ROC Curves of Top 5 Core Genes",
    x = "False Positive Rate (1 - Specificity)",
    y = "True Positive Rate (Sensitivity)",
    color = "Gene"
  ) +
  xlim(0, 1) +
  ylim(0, 1) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
    axis.text = element_text(size = 10),
    axis.title = element_text(size = 11),
    legend.position = "top",
    legend.title = element_text(size = 10, face = "bold")
  )

# 保存
ggsave("results/figures/Fig_ROC_core_genes.pdf", p_roc_single, width = 10, height = 8)
ggsave("results/figures/Fig_ROC_core_genes.jpg", p_roc_single, width = 10, height = 8, dpi = 300)
cat("ROC绘图完成\n")






library(ggplot2)
library(pROC)
library(dplyr)

# 切换工作目录
setwd("C:/Users/ASUS/Desktop/7月重头再来/5 ML and SHAP/第二次8.3")

# 1 读取样本与表达数据
expr_train <- read.csv("expr_79genes_extracted.csv", row.names = 1, check.names = FALSE)
meta_train <- read.csv("sample_metadata.csv", stringsAsFactors = FALSE)

# ==========修复分组赋值BUG==========
meta_train$group <- tolower(meta_train$group)
# 匹配正常/肿瘤标签
meta_train$group[grep("control|normal|healthy", meta_train$group)] <- "control"
meta_train$group[grep("crc|cancer|tumor|tumour|carcinoma|colorectal", meta_train$group)] <- "crc"
meta_train$group <- factor(meta_train$group, levels = c("control", "crc"))
# 校验分组
cat("训练集分组统计：\n")
print(table(meta_train$group))


# 表达矩阵转置合并
expr_t <- as.data.frame(t(expr_train))
expr_t$sample_id <- rownames(expr_t)
train_data <- merge(meta_train, expr_t, by = "sample_id")
train_data$sample_id <- NULL

# 提取基因列
gene_cols <- setdiff(colnames(train_data), c("group_raw", "group_clean", "group"))

# 标准化
expr_mat <- train_data[, gene_cols]
train_means <- apply(expr_mat, 2, mean)
train_sds <- apply(expr_mat, 2, sd)
train_data[, gene_cols] <- scale(expr_mat, center = train_means, scale = train_sds)

# 读取SHAP基因
shap_import <- read.csv("results/tables/SHAP_importance_ranking.csv")
top5_genes <- shap_import$Gene[1:5]
line_cols <- c("#d62728", "#1f77b4", "#2ca02c", "#ff7f0e", "#9467bd")
names(line_cols) <- top5_genes

# 绘制ROC数据存储
roc_all_data <- data.frame()
auc_info <- list() # 存储基因、AUC、对应颜色
for (gene in top5_genes) {
  roc_obj <- roc(response = train_data$group, predictor = train_data[[gene]], quiet = TRUE)
  auc_val <- round(as.numeric(auc(roc_obj)), 3)
  
  temp_df <- data.frame(
    fpr = 1 - roc_obj$specificities,
    tpr = roc_obj$sensitivities,
    gene = gene
  )
  roc_all_data <- rbind(roc_all_data, temp_df)
  auc_info[[gene]] <- list(auc = auc, col = line_cols[gene])
}

# 构建标注专用数据表：每行一条基因，包含y坐标、颜色、文本
anno_df <- data.frame(
  gene = top5_genes,
  auc = sapply(auc_info, function(x) x$auc),
  color = line_cols[top5_genes],
  # 从上到下5行文本y坐标依次递减
  y_pos = c(0.32, 0.28, 0.24, 0.20, 0.16),
  x_start = 0.62,  # 彩色短线起始x
  x_end = 0.66     # 彩色短线结束x（短线长度）
)
anno_df$label_text <- paste0(anno_df$gene, " AUC = ", anno_df$auc)

# 绘图主体
p_roc_single <- ggplot(roc_all_data, aes(x = fpr, y = tpr, color = gene)) +
  geom_line(linewidth = 1.3) + # 曲线加粗
  geom_abline(intercept = 0, slope = 1, linetype = "dashed", color = "gray40", linewidth = 0.8) +
  scale_color_manual(values = line_cols) +
  # 1. 绘制每条基因对应的彩色短横线
  geom_segment(
    data = anno_df,
    inherit.aes = FALSE,
    aes(x = x_start, xend = x_end, y = y_pos, yend = y_pos, color = gene),
    linewidth = 1.2
  ) +
  # 2. 短线右侧标注文字
  geom_text(
    data = anno_df,
    inherit.aes = FALSE,
    aes(x = x_end + 0.015, y = y_pos, label = label_text),
    hjust = 0, size = 3.4, color = "black"
  ) +
  # 半透明白色背景框包住全部标注
  annotate(
    "rect",
    xmin = 0.61, xmax = 0.93,
    ymin = 0.14, ymax = 0.34,
    fill = "white", alpha = 0.8, color = "gray60"
  ) +
  labs(
    title = "ROC Curves of Top 5 Core Genes",
    x = "False Positive Rate (1 - Specificity)",
    y = "True Positive Rate\n(Sensitivity)",
    color = "Gene"
  ) +
  xlim(0, 1) +
  ylim(0, 1) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
    axis.text = element_text(size = 10),
    axis.title = element_text(size = 11),
    axis.title.y = element_text(vjust = 0.5),
    legend.position = "top",
    legend.title = element_text(size = 10, face = "bold")
  )

# 保存
ggsave("results/figures/Fig_ROC_core_genes.pdf", p_roc_single, width = 10, height = 8)
ggsave("results/figures/Fig_ROC_core_genes.jpg", p_roc_single, width = 10, height = 8, dpi = 300)
cat("ROC图绘制完成，右下角标注带对应颜色短线\n")





#--------------------------- 5.7 核心基因表达热图 ------------------------------#
# 最优模型基因在各样本中的表达模式
expr_core <- as.matrix(x_train_best)
rownames(expr_core) <- rownames(x_train_best)

annotation_df <- data.frame(
  Group = y_train_best,
  row.names = rownames(x_train_best)
)

ann_colors <- list(Group = c(control = "#377EB8", crc = "#E41A1C"))

pheatmap_expr <- pheatmap(
  t(expr_core),
  scale = "row",
  annotation_col = annotation_df,
  annotation_colors = ann_colors,
  color = colorRampPalette(c("navy", "white", "firebrick3"))(100),
  fontsize_row = 8,
  fontsize_col = 6,
  show_colnames = FALSE,
  main = "Expression Patterns of Core Genes\n(Plasticizer-CRC intersection targets)",
  cluster_rows = TRUE,
  cluster_cols = TRUE,
  treeheight_row = 15,
  treeheight_col = 15,
  border_color = NA
)

pdf("results/figures/Fig_core_gene_expression_heatmap.pdf", width = 10, height = 8)
print(pheatmap_expr)
dev.off()

jpeg("results/figures/Fig_core_gene_expression_heatmap.jpg", width = 3000, height = 2400, res = dpi_val, quality = 100)
print(pheatmap_expr)
dev.off()

cat("SHAP分析完成\n\n")

#==============================================================================#
#=========================== 6. 结果汇总输出 ==================================#
#==============================================================================#

cat("=== 步骤6：结果汇总 ===\n")

# SHAP重要性排名
shap_importance <- data.frame(
  Gene = colnames(shap_obj$S),
  Mean_Absolute_SHAP = apply(shap_obj$S, 2, function(x) mean(abs(x))),
  stringsAsFactors = FALSE
)
shap_importance <- shap_importance[order(-shap_importance$Mean_Absolute_SHAP), ]
write.csv(shap_importance, "results/tables/SHAP_importance_ranking.csv", row.names = FALSE)

# 最优模型信息
best_info <- data.frame(
  Item = c("最优模型名称", "训练集AUC", "验证集1(GSE24514) AUC",
           "验证集2(GSE44076) AUC", "平均AUC", "纳入基因数", "纳入基因列表"),
  Value = c(best_model_name,
            val_results$train_auc[which.max(val_results$mean_auc)],
            val_results$val1_auc[which.max(val_results$mean_auc)],
            val_results$val2_auc[which.max(val_results$mean_auc)],
            val_results$mean_auc[which.max(val_results$mean_auc)],
            length(best_features),
            paste(best_features, collapse = ", "))
)
write.csv(best_info, "results/tables/best_model_summary.csv", row.names = FALSE)

# 输出文件清单
cat("\n========== 分析完成！输出文件清单 ==========\n")
cat("表格文件：\n")
cat("  - results/tables/cv_auc_results.csv       交叉验证AUC结果\n")
cat("  - results/tables/external_validation_auc.csv  外部验证AUC结果\n")
cat("  - results/tables/SHAP_importance_ranking.csv  SHAP重要性排名\n")
cat("  - results/tables/best_model_summary.csv    最优模型汇总\n\n")
cat("图形文件（PDF + JPG 300dpi）：\n")
cat("  - Fig_AUC_heatmap                    AUC热图（核心图）\n")
cat("  - Fig_SHAP_summary                   SHAP汇总蜂群图\n")
cat("  - Fig_SHAP_importance_bar            SHAP重要性条形图\n")
cat("  - Fig_SHAP_dependence_top5           Top5基因SHAP依赖图\n")
cat("  - Fig_SHAP_force_plot                SHAP力图\n")
cat("  - Fig_SHAP_waterfall                 SHAP瀑布图\n")
cat("  - Fig_ROC_core_genes                 核心基因ROC曲线\n")
cat("  - Fig_core_gene_expression_heatmap   核心基因表达热图\n")
cat("==============================================\n")

cat("\n最优模型：", best_model_name, "\n")
cat("平均AUC：", val_results$mean_auc[which.max(val_results$mean_auc)], "\n")
cat("Top5核心基因（按SHAP重要性）：", paste(shap_importance$Gene[1:5], collapse = ", "), "\n")


